
import React, { useState, useEffect, useRef } from 'react';
import { ShoppingCart, LayoutDashboard, Home, Search, ChevronRight, Package, CreditCard, CheckCircle, Trash2, Plus, Sparkles, Lock, LogOut, Settings, Save, Heart, UserPlus, Users, MapPin, List, Eye, Clock, ClipboardList, XCircle, FileText, Printer, ArrowLeft, Image as ImageIcon, Layers, Upload, X } from 'lucide-react';
import { Product, CartItem, Order, View, AdminUser, AdminSubView } from './types';
import { generateProductDescription } from './services/geminiService';

const INITIAL_PRODUCTS: Product[] = [
  {
    id: '1',
    code: 'UC-COMBO-01',
    name: 'রাজকীয় মেরুন জামদানি ও কুন্দন সেট',
    price: 12500,
    description: 'একটি প্রিমিয়াম মেরুন ঢাকai জামদানি শাড়ি এবং তার সাথে ম্যাচিং করা স্টাইলিশ কুন্দন গয়না সেট। উৎসবের জন্য সম্পূর্ণ রাজকীয় সাজ।',
    category: 'Combo Offer',
    images: ['https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&q=80&w=600&h=600', 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&q=80&w=600&h=600'],
    colors: ['Maroon', 'Red']
  },
  {
    id: '2',
    code: 'UC-COMBO-02',
    name: 'নেভি ব্লু কাতান ও মুক্তার গয়না',
    price: 14000,
    description: 'আভিজাত্যের মেলবন্ধন। একটি নেভি ব্লু পিওর কাতান শাড়ি এবং সাথে এক সেট সাদা মুক্তার নেকলেস ও দুল।',
    category: 'Combo Offer',
    images: ['https://images.unsplash.com/photo-1583391733956-6c78276477e2?auto=format&fit=crop&q=80&w=600&h=600', 'https://images.unsplash.com/photo-1601344621401-081831414457?auto=format&fit=crop&q=80&w=600&h=600'],
    colors: ['Navy Blue']
  },
  {
    id: '3',
    code: 'UC-COMBO-03',
    name: 'সবুজ মসলিন ও এন্টিক চোকার সেট',
    price: 9800,
    description: 'হালকা ওজনের পান্না সবুজ মসলিন সিল্ক শাড়ি এবং একটি আকর্ষণীয় এন্টিক গোল্ড ফিনিশ চোকার। যেকোনো অনুষ্ঠানে আপনাকে দেখাবে অনন্য।',
    category: 'Combo Offer',
    images: ['https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?auto=format&fit=crop&q=80&w=600&h=600', 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?auto=format&fit=crop&q=80&w=600&h=600'],
    colors: ['Emerald Green', 'Light Green']
  },
  {
    id: '4',
    code: 'UC-COMBO-04',
    name: 'হলুদ টাঙ্গাইল শাড়ি ও পোড়ামাটির গয়না',
    price: 5500,
    description: 'দেশি সাজে অনন্য। বাসন্তী হলুদ টাঙ্গাইল তাঁত শাড়ি এবং হাতে তৈরি চমৎকার পোড়ামাটির (Terracotta) গয়না সেট।',
    category: 'Combo Offer',
    images: ['https://images.unsplash.com/photo-1574297500578-afae55026ff3?auto=format&fit=crop&q=80&w=600&h=600'],
    colors: ['Yellow', 'Orange']
  },
  {
    id: '5',
    code: 'UC-COMBO-05',
    name: 'ব্ল্যাক বানারসি ও ঝুমকা কম্বো',
    price: 16500,
    description: 'চিরসবুজ কালো বানারসি শাড়ি এবং এক জোড়া বড় আকৃতির জমকালো গোল্ড প্লেটেড ঝুমকা। গ্ল্যামারাস লুকের জন্য সেরা পছন্দ।',
    category: 'Combo Offer',
    images: ['https://images.unsplash.com/photo-1610030469668-935142b96fe4?auto=format&fit=crop&q=80&w=600&h=600'],
    colors: ['Black']
  },
  {
    id: '6',
    code: 'UC-COMBO-06',
    name: 'পিংক সফট সিল্ক ও স্টোন গয়না',
    price: 11200,
    description: 'আরামদায়ক সফট সিল্ক শাড়ি এবং সাথে ম্যাচিং স্টোন স্টাডেড নেকলেস ও ইয়াররিং। মার্জিত ও আধুনিক সাজের জন্য পারফেক্ট।',
    category: 'Combo Offer',
    images: ['https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?auto=format&fit=crop&q=80&w=600&h=600'],
    colors: ['Pastel Pink', 'Rose Gold']
  },
  {
    id: '7',
    code: 'UC-COMBO-07',
    name: 'সাদা জামদানি ও রুপালি অক্সিডাইজ সেট',
    price: 8900,
    description: 'শুভ্র সাদা ঢাকাই জামদানি এবং তার সাথে ট্র্যাডিশনাল রুপালি অক্সিডাইজড গয়নার অপূর্ব মেলবন্ধন।',
    category: 'Combo Offer',
    images: ['https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&q=80&w=600&h=600'],
    colors: ['White', 'Off White']
  },
  {
    id: '8',
    code: 'UC-COMBO-08',
    name: 'বেগুনি সিল্ক ও মিনাকারি সেট',
    price: 13500,
    description: 'গাঢ় বেগুনি সিল্ক শাড়ি এবং তার সাথে চমৎকার মিনাকারি করা গোল্ডেন ফিনিশ গয়না। আভিজাত্যের নতুন নাম।',
    category: 'Combo Offer',
    images: ['https://images.unsplash.com/photo-1583391733956-6c78276477e2?auto=format&fit=crop&q=80&w=600&h=600'],
    colors: ['Purple', 'Violet']
  },
  {
    id: '9',
    code: 'UC-COMBO-09',
    name: 'অর্গানজা ও ফ্লোরাল মোটিফ গয়না',
    price: 7800,
    description: 'আধুনিক ট্রেন্ডি অর্গানজা শাড়ি এবং সাথে সিম্পল ফ্লোরাল মোটিফের গয়না সেট। তরুণীদের জন্য সেরা কম্বো।',
    category: 'Combo Offer',
    images: ['https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?auto=format&fit=crop&q=80&w=600&h=600'],
    colors: ['Peach', 'Sky Blue']
  },
  {
    id: '10',
    code: 'UC-COMBO-10',
    name: 'ব্রাইডাল রেড কাতান ও হেভি গয়না',
    price: 25000,
    description: 'বিয়ের কনের জন্য সম্পূর্ণ প্যাকেজ। একটি প্রিমিয়াম লাল কাতান শাড়ি এবং সাথে ব্রাইডাল হেভি গোল্ডেন গয়না সেট।',
    category: 'Combo Offer',
    images: ['https://images.unsplash.com/photo-1583391733956-6c78276477e2?auto=format&fit=crop&q=80&w=600&h=600'],
    colors: ['Wedding Red']
  }
];

const App: React.FC = () => {
  const [view, setView] = useState<View>('home');
  const [adminSubView, setAdminSubView] = useState<AdminSubView>('dashboard');
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [activeImageIdx, setActiveImageIdx] = useState(0);
  const [selectedColor, setSelectedColor] = useState('');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [isAiLoading, setIsAiLoading] = useState(false);
  
  // Admin & Upload state
  const [tempUploadedImages, setTempUploadedImages] = useState<string[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [adminUsers, setAdminUsers] = useState<AdminUser[]>([]);
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);
  const [loginError, setLoginError] = useState('');
  const [currentUser, setCurrentUser] = useState<AdminUser | null>(null);
  
  const [captcha, setCaptcha] = useState({ a: 0, b: 0 });
  const [captchaInput, setCaptchaInput] = useState('');

  const generateCaptcha = () => {
    setCaptcha({
      a: Math.floor(Math.random() * 10) + 1,
      b: Math.floor(Math.random() * 10) + 1
    });
    setCaptchaInput('');
  };

  useEffect(() => {
    const savedProducts = localStorage.getItem('products');
    if (savedProducts) setProducts(JSON.parse(savedProducts));
    
    const savedOrders = localStorage.getItem('orders');
    if (savedOrders) setOrders(JSON.parse(savedOrders));

    const savedUsers = localStorage.getItem('admin_users');
    if (savedUsers) {
      setAdminUsers(JSON.parse(savedUsers));
    } else {
      const defaultUser: AdminUser = { id: '1', username: 'Azhar', password: 'Azhar', role: 'admin' };
      setAdminUsers([defaultUser]);
      localStorage.setItem('admin_users', JSON.stringify([defaultUser]));
    }

    const adminSession = localStorage.getItem('admin_session');
    if (adminSession) {
      const user = JSON.parse(adminSession);
      setIsAdminLoggedIn(true);
      setCurrentUser(user);
    }
    generateCaptcha();
  }, []);

  const saveProducts = (updated: Product[]) => {
    setProducts(updated);
    localStorage.setItem('products', JSON.stringify(updated));
  };

  const handleRemoveProduct = (id: string) => {
    if (window.confirm('আপনি কি এই কালেকশনটি মুছে ফেলতে চান?')) {
      const updated = products.filter(p => p.id !== id);
      saveProducts(updated);
    }
  };

  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id && item.selectedColor === selectedColor);
      if (existing) {
        return prev.map(item => (item.id === product.id && item.selectedColor === selectedColor) ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { ...product, quantity: 1, selectedColor: selectedColor || (product.colors?.[0] || '') }];
    });
  };

  const removeFromCart = (id: string, color?: string) => {
    setCart(prev => prev.filter(item => !(item.id === id && item.selectedColor === color)));
  };

  const calculateTotal = () => cart.reduce((acc, item) => acc + (item.price * item.quantity), 0);

  const handleCheckout = (customerInfo: any) => {
    const newOrder: Order = {
      id: Math.random().toString(36).substr(2, 9).toUpperCase(),
      items: [...cart],
      total: calculateTotal(),
      customerName: customerInfo.name,
      customerEmail: customerInfo.email,
      customerPhone: customerInfo.phone,
      customerAddress: customerInfo.address,
      status: 'pending',
      createdAt: new Date().toISOString(),
    };
    const updatedOrders = [newOrder, ...orders];
    setOrders(updatedOrders);
    localStorage.setItem('orders', JSON.stringify(updatedOrders));
    setCart([]);
    setView('order-success');
  };

  const handleAdminLogin = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const inputUsername = formData.get('username') as string;
    const inputPassword = formData.get('password') as string;

    if (parseInt(captchaInput) !== (captcha.a + captcha.b)) {
      setLoginError('ক্যাপচা সঠিক হয়নি!');
      generateCaptcha();
      return;
    }

    const user = adminUsers.find(u => u.username === inputUsername && u.password === inputPassword);
    if (user) {
      setIsAdminLoggedIn(true);
      setCurrentUser(user);
      setLoginError('');
      localStorage.setItem('admin_session', JSON.stringify(user));
      setAdminSubView('dashboard');
    } else {
      setLoginError('ভুল ইউজার নেম অথবা পাসওয়ার্ড!');
      generateCaptcha();
    }
  };

  const handleAdminLogout = () => {
    setIsAdminLoggedIn(false);
    setCurrentUser(null);
    localStorage.removeItem('admin_session');
    setView('home');
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    const fileList = Array.from(files);
    const promises = fileList.map(file => {
      return new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => {
          resolve(reader.result as string);
        };
        reader.readAsDataURL(file);
      });
    });

    Promise.all(promises).then(results => {
      setTempUploadedImages(prev => [...prev, ...results]);
    });
  };

  const handleAddProduct = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const name = formData.get('name') as string;
    const code = formData.get('code') as string;
    const price = parseFloat(formData.get('price') as string);
    const category = formData.get('category') as string;
    const colors = (formData.get('colors') as string).split(',').map(c => c.trim()).filter(c => c);
    
    // Combining manual URL links and uploaded files
    const manualImages = (formData.get('images') as string).split('\n').map(i => i.trim()).filter(i => i);
    const finalImages = [...tempUploadedImages, ...manualImages];

    if (finalImages.length === 0) {
      alert('অনুগ্রহ করে অন্তত একটি ছবি যোগ করুন!');
      return;
    }

    setIsAiLoading(true);
    const desc = await generateProductDescription(name, category);
    const newProduct: Product = {
      id: Date.now().toString(),
      code: code || `UC-${Math.floor(Math.random()*900)+100}`,
      name,
      price,
      category,
      description: desc,
      images: finalImages,
      colors
    };
    const updated = [...products, newProduct];
    saveProducts(updated);
    setIsAiLoading(false);
    setTempUploadedImages([]);
    e.currentTarget.reset();
    alert('সফলভাবে কালেকশন যোগ করা হয়েছে!');
  };

  const printInvoice = (order: Order) => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;
    const html = `
      <html>
        <head>
          <title>Invoice - ${order.id}</title>
          <style>
            @import url('https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;700&display=swap');
            body { font-family: 'Hind Siliguri', sans-serif; padding: 40px; color: #333; }
            .header { display: flex; justify-content: space-between; border-bottom: 2px solid #e11d48; padding-bottom: 20px; margin-bottom: 30px; }
            .brand { color: #e11d48; font-size: 24px; font-weight: bold; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            th { text-align: left; background: #f8fafc; padding: 12px; border-bottom: 1px solid #eee; }
            td { padding: 12px; border-bottom: 1px solid #eee; }
            .total { text-align: right; font-size: 20px; font-weight: bold; color: #e11d48; margin-top: 20px; }
          </style>
        </head>
        <body>
          <div class="header">
            <div class="brand">Unique Collection By Mehezabin</div>
            <div style="text-align: right">
              <div>Invoice ID: #${order.id}</div>
              <div>Date: ${new Date(order.createdAt).toLocaleDateString('bn-BD')}</div>
            </div>
          </div>
          <div>
            <strong>Customer: ${order.customerName}</strong><br/>
            Phone: ${order.customerPhone}<br/>
            Address: ${order.customerAddress}
          </div>
          <table>
            <thead><tr><th>Code</th><th>Item</th><th>Color</th><th>Price</th><th>Qty</th><th>Subtotal</th></tr></thead>
            <tbody>
              ${order.items.map(item => `
                <tr>
                  <td>${item.code}</td>
                  <td>${item.name}</td>
                  <td>${item.selectedColor || 'N/A'}</td>
                  <td>৳${item.price.toLocaleString()}</td>
                  <td>${item.quantity}</td>
                  <td>৳${(item.price * item.quantity).toLocaleString()}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
          <div class="total">Total Payable: ৳${(order.total + 120).toLocaleString()} (Delivery Inc.)</div>
        </body>
      </html>
    `;
    printWindow.document.write(html);
    printWindow.document.close();
  };

  const renderAdminContent = () => {
    if (selectedOrder) {
      const order = selectedOrder;
      return (
        <div className="bg-white p-10 rounded-[2.5rem] border border-rose-100 shadow-2xl space-y-8 animate-in fade-in slide-in-from-bottom-4">
          <div className="flex justify-between items-start">
            <button onClick={() => setSelectedOrder(null)} className="p-3 bg-gray-50 text-gray-400 hover:text-rose-600 rounded-full transition-colors"><ArrowLeft size={24} /></button>
            <span className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest ${order.status === 'pending' ? 'bg-amber-100 text-amber-700' : 'bg-green-100 text-green-700'}`}>
              {order.status === 'pending' ? 'পেন্ডিং' : 'কনফার্ম'}
            </span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
            <div className="space-y-4">
              <h3 className="text-xs font-black text-gray-400 uppercase font-hind">গ্রাহকের তথ্য</h3>
              <p className="text-2xl font-black text-gray-900 font-hind">{order.customerName}</p>
              <p className="text-lg font-bold text-rose-600 font-hind">{order.customerPhone}</p>
              <div className="flex text-gray-400 font-hind leading-relaxed"><MapPin size={18} className="mr-2 shrink-0 mt-1" /> {order.customerAddress}</div>
            </div>
            <div className="space-y-4 md:text-right">
              <h3 className="text-xs font-black text-gray-400 uppercase font-hind">অর্ডার সারসংক্ষেপ</h3>
              <p className="text-xl font-mono font-black text-rose-600 leading-none">#{order.id}</p>
              <p className="text-4xl font-black text-gray-900 font-hind">৳{order.total.toLocaleString()}</p>
            </div>
          </div>
          <div className="divide-y divide-rose-50">
            {order.items.map((item, idx) => (
              <div key={idx} className="py-4 flex justify-between items-center font-hind">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 rounded-xl bg-rose-50 overflow-hidden shrink-0"><img src={item.images[0]} className="w-full h-full object-cover" alt="" /></div>
                  <div>
                    <p className="font-black text-gray-800">{item.name}</p>
                    <p className="text-[10px] font-black text-rose-500 uppercase">Code: {item.code} | Color: {item.selectedColor}</p>
                  </div>
                </div>
                <div className="text-right"><p className="font-black">৳{(item.price * item.quantity).toLocaleString()}</p></div>
              </div>
            ))}
          </div>
          <div className="pt-8 flex gap-4">
            {order.status === 'pending' && <button onClick={() => { 
                const updated = orders.map(o => o.id === order.id ? {...o, status: 'confirmed'} : o);
                setOrders(updated); localStorage.setItem('orders', JSON.stringify(updated));
                setSelectedOrder(null);
                printInvoice(order);
              }} className="flex-1 bg-green-600 text-white py-5 rounded-2xl font-black font-hind">অর্ডার কনফার্ম ও ইনভয়েস</button>}
            <button onClick={() => printInvoice(order)} className="flex-1 bg-blue-600 text-white py-5 rounded-2xl font-black font-hind">ইনভয়েস ডাউনলোড</button>
          </div>
        </div>
      );
    }

    switch (adminSubView) {
      case 'dashboard':
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div onClick={() => setAdminSubView('add-product')} className="bg-white p-8 rounded-[2rem] border border-rose-50 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all cursor-pointer group font-hind">
              <div className="w-16 h-16 bg-rose-50 text-rose-600 rounded-2xl flex items-center justify-center mb-6 shadow-inner"><Plus size={32} /></div>
              <h4 className="text-xl font-black text-gray-900">নতুন কম্বো কালেকশন অ্যাড</h4>
              <p className="text-xs text-gray-400 mt-2">মোবাইল বা পিসি থেকে ফটো আপলোড করুন</p>
            </div>
            <div onClick={() => setAdminSubView('new-orders')} className="bg-white p-8 rounded-[2rem] border border-rose-50 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all cursor-pointer group font-hind">
              <div className="w-16 h-16 bg-amber-50 text-amber-600 rounded-2xl flex items-center justify-center mb-6 shadow-inner"><Clock size={32} /></div>
              <h4 className="text-xl font-black text-gray-900">নতুন অর্ডার গুলো ({orders.filter(o => o.status === 'pending').length})</h4>
            </div>
            <div onClick={() => setAdminSubView('confirmed-orders')} className="bg-white p-8 rounded-[2rem] border border-rose-50 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all cursor-pointer group font-hind">
              <div className="w-16 h-16 bg-green-50 text-green-600 rounded-2xl flex items-center justify-center mb-6 shadow-inner"><CheckCircle size={32} /></div>
              <h4 className="text-xl font-black text-gray-900">কনফার্ম করা অর্ডার</h4>
            </div>
          </div>
        );
      case 'add-product':
        return (
          <div className="max-w-4xl bg-white p-10 rounded-[2.5rem] border border-rose-50 shadow-sm space-y-8 font-hind">
            <h3 className="text-3xl font-black flex items-center"><Layers className="mr-3 text-rose-600" /> নতুন কালেকশন / কম্বো যোগ করুন</h3>
            <form className="grid grid-cols-1 md:grid-cols-2 gap-8" onSubmit={handleAddProduct}>
              <div className="space-y-2">
                <label className="text-xs font-black text-gray-400 uppercase tracking-widest px-2">কালেকশন কোড (SKU)</label>
                <input name="code" required className="w-full border-2 border-rose-50 bg-rose-50/30 p-5 rounded-2xl focus:ring-4 focus:ring-rose-50 outline-none font-bold" placeholder="UC-501" />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-black text-gray-400 uppercase tracking-widest px-2">কালেকশন নাম</label>
                <input name="name" required className="w-full border-2 border-rose-50 bg-rose-50/30 p-5 rounded-2xl focus:ring-4 focus:ring-rose-50 outline-none font-bold" placeholder="সিল্ক ও গয়না কম্বো" />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-black text-gray-400 uppercase tracking-widest px-2">মূল্য</label>
                <input name="price" type="number" required className="w-full border-2 border-rose-50 bg-rose-50/30 p-5 rounded-2xl focus:ring-4 focus:ring-rose-50 outline-none font-bold" placeholder="9500" />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-black text-gray-400 uppercase tracking-widest px-2">ক্যাটেগরি</label>
                <select name="category" className="w-full border-2 border-rose-50 bg-rose-50/30 p-5 rounded-2xl outline-none font-black appearance-none">
                  <option>Combo Offer</option>
                  <option>Exclusive Jamdani</option>
                  <option>Party Collection</option>
                  <option>New Arrival</option>
                </select>
              </div>
              <div className="space-y-2 md:col-span-2">
                <label className="text-xs font-black text-gray-400 uppercase tracking-widest px-2">কালার সমূহ (কমা দিয়ে লিখুন)</label>
                <input name="colors" className="w-full border-2 border-rose-50 bg-rose-50/30 p-5 rounded-2xl focus:ring-4 focus:ring-rose-50 outline-none font-bold" placeholder="Red, Maroon, Golden..." />
              </div>
              
              <div className="md:col-span-2 space-y-4">
                <label className="text-xs font-black text-gray-400 uppercase tracking-widest px-2">ফটো আপলোড করুন (মোবাইল/পিসি)</label>
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full border-4 border-dashed border-rose-100 bg-rose-50/20 p-10 rounded-[2rem] flex flex-col items-center justify-center cursor-pointer hover:border-rose-300 hover:bg-rose-50 transition-all group"
                >
                  <Upload size={48} className="text-rose-300 group-hover:text-rose-500 mb-4 transition-colors" />
                  <p className="text-lg font-black text-gray-500">ফটো সিলেক্ট করতে এখানে ক্লিক করুন</p>
                  <p className="text-sm text-gray-400 mt-2">আপনি একসাথে একাধিক ফটো সিলেক্ট করতে পারবেন</p>
                  <input 
                    type="file" 
                    ref={fileInputRef} 
                    onChange={handleFileChange} 
                    multiple 
                    accept="image/*" 
                    className="hidden" 
                  />
                </div>
                
                {/* Uploaded Previews */}
                {tempUploadedImages.length > 0 && (
                  <div className="flex flex-wrap gap-4 mt-4">
                    {tempUploadedImages.map((img, i) => (
                      <div key={i} className="relative w-24 h-24 rounded-xl overflow-hidden shadow-md group">
                        <img src={img} className="w-full h-full object-cover" alt="" />
                        <button 
                          type="button"
                          onClick={() => setTempUploadedImages(prev => prev.filter((_, idx) => idx !== i))}
                          className="absolute top-1 right-1 bg-white/80 p-1 rounded-full text-rose-600 hover:bg-rose-600 hover:text-white shadow-sm"
                        >
                          <X size={14} />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="space-y-2 md:col-span-2">
                <label className="text-xs font-black text-gray-400 uppercase tracking-widest px-2">অথবা ফটোর লিংক ব্যবহার করুন (প্রতি লাইনে একটি)</label>
                <textarea name="images" rows={3} className="w-full border-2 border-rose-50 bg-rose-50/30 p-5 rounded-2xl focus:ring-4 focus:ring-rose-50 outline-none font-bold" placeholder="https://image1.jpg" />
              </div>
              
              <button disabled={isAiLoading} type="submit" className="md:col-span-2 bg-rose-600 text-white py-6 rounded-2xl font-black text-xl hover:bg-rose-700 transition shadow-2xl shadow-rose-100 flex items-center justify-center space-x-3">
                {isAiLoading ? <><Clock className="animate-spin" /> <span>এআই ডেসক্রিপশন হচ্ছে...</span></> : <><span>কালেকশন পাবলিশ করুন</span></>}
              </button>
            </form>

            <div className="pt-10 border-t border-rose-50">
                <h4 className="text-2xl font-black mb-6 flex items-center"><List className="mr-3" /> বর্তমান কালেকশন লিস্ট ({products.length})</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {products.map(p => (
                    <div key={p.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-2xl border border-gray-100 hover:border-rose-100 transition-colors">
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 rounded-xl overflow-hidden bg-white"><img src={p.images[0]} className="w-full h-full object-cover" alt="" /></div>
                        <div className="min-w-0">
                          <div className="font-black text-gray-800 text-sm truncate max-w-[150px]">{p.name}</div>
                          <div className="text-[10px] text-rose-500 font-bold uppercase">Code: {p.code} | ৳{p.price.toLocaleString()}</div>
                        </div>
                      </div>
                      <button onClick={() => handleRemoveProduct(p.id)} className="text-gray-300 hover:text-rose-600 p-2 transition-colors"><Trash2 size={20} /></button>
                    </div>
                  ))}
                </div>
            </div>
          </div>
        );
      case 'new-orders':
      case 'confirmed-orders':
      case 'all-orders':
        const displayOrders = adminSubView === 'new-orders' ? orders.filter(o => o.status === 'pending') : 
                             adminSubView === 'confirmed-orders' ? orders.filter(o => o.status === 'confirmed') : orders;
        return (
          <div className="bg-white border border-rose-50 rounded-[3rem] overflow-hidden shadow-sm font-hind">
            <div className="p-10 border-b border-rose-50 bg-rose-50/20 flex justify-between items-center">
              <h3 className="font-black text-2xl">{adminSubView === 'new-orders' ? 'নতুন পেন্ডিং অর্ডার' : adminSubView === 'confirmed-orders' ? 'কনফার্ম করা অর্ডার' : 'সকল অর্ডার ইতিহাস'}</h3>
              <span className="bg-rose-600 text-white px-5 py-2 rounded-full font-black text-xs uppercase tracking-widest">{displayOrders.length} Orders</span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead className="bg-white border-b border-rose-50 text-[10px] text-gray-400 uppercase font-black tracking-widest">
                  <tr><th className="px-10 py-8">আইডি</th><th className="px-10 py-8">গ্রাহকের তথ্য</th><th className="px-10 py-8">মোট মূল্য</th><th className="px-10 py-8">অ্যাকশন</th></tr>
                </thead>
                <tbody className="divide-y divide-rose-50">
                  {displayOrders.length === 0 ? (
                    <tr><td colSpan={4} className="px-10 py-24 text-center text-gray-300 font-black italic text-2xl font-hind">কোনো অর্ডার পাওয়া যায়নি</td></tr>
                  ) : (
                    displayOrders.map(order => (
                      <tr key={order.id} className="hover:bg-rose-50/30 transition-colors">
                        <td className="px-10 py-8 font-mono font-black text-rose-600">#{order.id}</td>
                        <td className="px-10 py-8">
                          <div className="font-black text-gray-900">{order.customerName}</div>
                          <div className="text-xs text-rose-500 font-bold">{order.customerPhone}</div>
                        </td>
                        <td className="px-10 py-8 font-black text-gray-900">৳{order.total.toLocaleString()}</td>
                        <td className="px-10 py-8"><button onClick={() => setSelectedOrder(order)} className="bg-white border-2 border-rose-100 text-rose-600 p-3 rounded-xl hover:bg-rose-600 hover:text-white transition"><Eye size={20} /></button></td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        );
      default: return null;
    }
  };

  return (
    <div className="min-h-screen flex flex-col selection:bg-rose-100 selection:text-rose-900">
      <nav className="bg-white border-b sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 h-20 flex justify-between items-center">
          <div className="flex items-center cursor-pointer" onClick={() => setView('home')}>
            <div className="w-12 h-12 bg-rose-600 rounded-full flex items-center justify-center text-white mr-3 shadow-lg shadow-rose-200"><Heart size={24} fill="currentColor" /></div>
            <div className="flex flex-col font-hind">
              <span className="text-xl md:text-2xl font-black bg-clip-text text-transparent bg-gradient-to-r from-rose-600 to-amber-600 leading-none">Unique Collection By Mehezabin</span>
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-[0.2em]">Premium Saree Boutique</span>
            </div>
          </div>
          <div className="flex items-center space-x-8 font-hind">
            <button onClick={() => setView('home')} className={`text-gray-600 hover:text-rose-600 font-bold transition-colors ${view === 'home' ? 'text-rose-600' : ''}`}>হোম</button>
            <button onClick={() => { setView('admin'); setSelectedOrder(null); }} className={`text-gray-600 hover:text-rose-600 font-bold flex items-center transition-colors ${view === 'admin' ? 'text-rose-600' : ''}`}><LayoutDashboard className="mr-1" size={18} /> এডমিন</button>
            <div className="relative cursor-pointer group" onClick={() => setView('cart')}>
              <ShoppingCart className={`text-gray-600 group-hover:text-rose-600 transition-colors ${view === 'cart' ? 'text-rose-600' : ''}`} />
              {cart.length > 0 && <span className="absolute -top-2 -right-2 bg-amber-500 text-white text-[10px] font-black rounded-full w-5 h-5 flex items-center justify-center">{cart.reduce((a, b) => a + b.quantity, 0)}</span>}
            </div>
          </div>
        </div>
      </nav>

      <main className="flex-grow max-w-7xl mx-auto w-full px-4 py-10">
        {view === 'home' && (
          <div className="space-y-12 font-hind">
            <div className="relative rounded-[3rem] overflow-hidden h-[400px] md:h-[500px] shadow-2xl group">
              <img src="https://images.unsplash.com/photo-1574297500578-afae55026ff3?auto=format&fit=crop&q=80&w=1200&h=600" className="w-full h-full object-cover transition duration-1000 group-hover:scale-105" alt="" />
              <div className="absolute inset-0 bg-gradient-to-r from-rose-900/80 via-rose-900/40 to-transparent flex items-center px-10 md:px-24">
                <div className="text-white space-y-6 max-w-xl">
                  <h1 className="text-4xl md:text-6xl font-black leading-tight drop-shadow-lg">সাজুন নিজের পছন্দের কম্বোতে</h1>
                  <p className="text-xl text-rose-50/90 font-medium">Unique Collection By Mehezabin-এ এখন পাচ্ছেন প্রিমিয়াম শাড়ি ও জুয়েলারি কম্বো অফার। আভিজাত্য এবার আপনার হাতের মুঠোয়।</p>
                  <button onClick={() => window.scrollTo({top: 800, behavior: 'smooth'})} className="bg-white text-rose-700 px-10 py-5 rounded-full font-black shadow-2xl flex items-center space-x-2"><span>কালেকশন দেখুন</span><ChevronRight size={20} /></button>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-10">
              {products.map(product => (
                <div key={product.id} className="bg-white rounded-[2rem] border border-gray-50 hover:shadow-[0_20px_50px_rgba(225,29,72,0.12)] transition-all duration-500 group overflow-hidden flex flex-col">
                  <div className="h-80 overflow-hidden relative bg-rose-50/20">
                    <img src={product.images[0]} className="w-full h-full object-cover transition duration-700 group-hover:scale-110" alt={product.name} />
                    <div className="absolute top-4 left-4 bg-white/90 backdrop-blur px-3 py-1 rounded-lg text-[10px] font-black text-rose-600 uppercase tracking-widest shadow-sm">Code: {product.code}</div>
                    <button onClick={() => { setSelectedProduct(product); setView('product'); setActiveImageIdx(0); setSelectedColor(product.colors?.[0] || ''); }} className="absolute bottom-6 right-6 bg-rose-600 p-4 rounded-2xl shadow-xl text-white hover:bg-rose-700 transition transform hover:-translate-y-2 translate-y-12 opacity-0 group-hover:translate-y-0 group-hover:opacity-100"><Eye size={20} /></button>
                  </div>
                  <div className="p-8 flex-grow flex flex-col cursor-pointer" onClick={() => { setSelectedProduct(product); setView('product'); setActiveImageIdx(0); setSelectedColor(product.colors?.[0] || ''); }}>
                    <h3 className="text-xl font-black text-gray-800 mb-3 truncate group-hover:text-rose-600 transition-colors">{product.name}</h3>
                    <div className="flex justify-between items-end mt-auto">
                      <div>
                        <p className="text-xs font-bold text-gray-400 uppercase mb-1">প্রাইস</p>
                        <p className="text-2xl font-black text-rose-600">৳{product.price.toLocaleString()}</p>
                      </div>
                      <div className="text-rose-100 group-hover:text-rose-500 transition-colors"><Heart size={24} /></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {view === 'product' && selectedProduct && (
          <div className="bg-white rounded-[3rem] p-6 md:p-16 shadow-sm border border-gray-50 font-hind">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-20">
              <div className="space-y-6">
                <div className="rounded-[2.5rem] overflow-hidden border border-rose-50 shadow-inner bg-rose-50/20 group aspect-[4/5]">
                  <img src={selectedProduct.images[activeImageIdx]} className="w-full h-full object-cover transition duration-700 group-hover:scale-105" alt="" />
                </div>
                <div className="flex gap-4 overflow-x-auto pb-4">
                    {selectedProduct.images.map((img, i) => (
                        <div key={i} onClick={() => setActiveImageIdx(i)} className={`w-24 h-24 rounded-2xl overflow-hidden cursor-pointer border-4 transition-all shrink-0 ${activeImageIdx === i ? 'border-rose-500 scale-95 shadow-lg' : 'border-transparent opacity-70 hover:opacity-100'}`}>
                            <img src={img} className="w-full h-full object-cover" alt="" />
                        </div>
                    ))}
                </div>
              </div>
              <div className="space-y-10 py-4">
                <div className="space-y-4">
                  <div className="flex justify-between items-start">
                    <span className="bg-rose-50 text-rose-600 px-4 py-1.5 rounded-full text-xs font-black uppercase tracking-widest">Code: {selectedProduct.code}</span>
                    <span className="bg-green-50 text-green-600 px-4 py-1.5 rounded-full text-xs font-black uppercase tracking-widest">In Stock</span>
                  </div>
                  <h1 className="text-4xl md:text-5xl font-black text-gray-900 leading-tight">{selectedProduct.name}</h1>
                  <p className="text-4xl md:text-5xl font-black text-rose-600">৳{selectedProduct.price.toLocaleString()}</p>
                </div>

                {selectedProduct.colors && selectedProduct.colors.length > 0 && (
                  <div className="space-y-4">
                    <h3 className="font-black text-gray-400 uppercase text-xs tracking-widest">পছন্দের কালার সিলেক্ট করুন:</h3>
                    <div className="flex flex-wrap gap-3">
                        {selectedProduct.colors.map(color => (
                            <button key={color} onClick={() => setSelectedColor(color)} className={`px-6 py-3 rounded-2xl font-black text-sm transition-all border-2 ${selectedColor === color ? 'bg-rose-600 border-rose-600 text-white shadow-xl shadow-rose-200' : 'bg-white border-rose-50 text-gray-500 hover:border-rose-200'}`}>{color}</button>
                        ))}
                    </div>
                  </div>
                )}

                <div className="border-t border-b border-rose-50 py-10">
                  <h3 className="font-black text-gray-900 mb-6 flex items-center text-xl"><Sparkles className="text-amber-500 mr-2" size={24} /> বর্ণনা</h3>
                  <p className="text-gray-600 leading-relaxed text-lg whitespace-pre-line font-medium">{selectedProduct.description}</p>
                </div>
                <div className="flex space-x-6">
                  <button onClick={() => { addToCart(selectedProduct); setView('cart'); }} className="flex-1 bg-rose-600 text-white py-6 rounded-[1.5rem] font-black hover:bg-rose-700 transition shadow-2xl shadow-rose-100 text-xl transform hover:-translate-y-1">ব্যাগ-এ যোগ করুন</button>
                  <button className="w-20 border-2 border-rose-100 rounded-[1.5rem] flex items-center justify-center text-rose-400 hover:bg-rose-50 transition"><Heart size={28} /></button>
                </div>
              </div>
            </div>
          </div>
        )}

        {view === 'cart' && (
          <div className="max-w-5xl mx-auto space-y-10 font-hind">
            <h1 className="text-5xl font-black text-gray-900 tracking-tight">আপনার শপিং ব্যাগ ({cart.length})</h1>
            {cart.length === 0 ? (
              <div className="text-center py-32 bg-white rounded-[3rem] border border-gray-50 shadow-sm">
                <div className="w-32 h-32 bg-rose-50 rounded-full flex items-center justify-center mx-auto mb-8"><ShoppingCart className="text-rose-200" size={56} /></div>
                <p className="text-3xl font-black text-gray-300">ব্যাগ খালি!</p>
                <button onClick={() => setView('home')} className="mt-8 bg-rose-600 text-white px-12 py-4 rounded-full font-black hover:bg-rose-700 transition shadow-xl">কালেকশন দেখুন</button>
              </div>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
                <div className="lg:col-span-2 space-y-6">
                  {cart.map((item, idx) => (
                    <div key={idx} className="bg-white p-6 rounded-[2rem] border border-rose-50 flex items-center space-x-8 hover:shadow-xl transition-all">
                      <div className="w-32 h-32 shrink-0 overflow-hidden rounded-2xl border bg-gray-50"><img src={item.images[0]} className="w-full h-full object-cover" alt="" /></div>
                      <div className="flex-grow">
                        <h3 className="text-xl font-black text-gray-800 leading-tight mb-2">{item.name}</h3>
                        <div className="flex items-center space-x-3 mb-2">
                            <span className="bg-rose-50 text-rose-500 px-3 py-1 rounded-lg text-[10px] font-black uppercase">Code: {item.code}</span>
                            <span className="bg-gray-50 text-gray-400 px-3 py-1 rounded-lg text-[10px] font-black uppercase">Color: {item.selectedColor}</span>
                        </div>
                        <p className="text-rose-600 font-black text-2xl">৳{item.price.toLocaleString()}</p>
                      </div>
                      <button onClick={() => removeFromCart(item.id, item.selectedColor)} className="text-rose-300 hover:text-rose-600 p-4 bg-rose-50 hover:bg-rose-100 rounded-2xl transition"><Trash2 size={24} /></button>
                    </div>
                  ))}
                </div>
                <div className="bg-white p-10 rounded-[2.5rem] border border-rose-50 h-fit space-y-10 shadow-sm">
                  <h3 className="text-2xl font-black text-gray-900 border-b border-rose-50 pb-6">অর্ডার সামারি</h3>
                  <div className="space-y-6 text-lg font-bold">
                    <div className="flex justify-between text-gray-400"><span>সাব-টোটাল</span><span className="text-gray-800 font-black">৳{calculateTotal().toLocaleString()}</span></div>
                    <div className="flex justify-between text-gray-400"><span>ডেলিভারি চার্জ</span><span className="text-gray-800 font-black">৳১২০</span></div>
                  </div>
                  <div className="flex justify-between text-3xl font-black text-rose-600 border-t border-rose-50 pt-8"><span>মোট</span><span>৳{(calculateTotal() + 120).toLocaleString()}</span></div>
                  <button onClick={() => setView('checkout')} className="w-full bg-rose-600 text-white py-6 rounded-[1.5rem] font-black hover:bg-rose-700 transition shadow-2xl shadow-rose-100 text-xl">অর্ডার করুন</button>
                </div>
              </div>
            )}
          </div>
        )}

        {view === 'checkout' && (
          <div className="max-w-xl mx-auto bg-white rounded-[3rem] border border-rose-50 p-12 shadow-2xl font-hind">
            <h1 className="text-4xl font-black mb-10 text-gray-900">শিপিং তথ্য দিন</h1>
            <form className="space-y-8" onSubmit={(e) => {
              e.preventDefault();
              const formData = new FormData(e.currentTarget);
              handleCheckout({
                name: formData.get('name'),
                phone: formData.get('phone'),
                address: formData.get('address'),
              });
            }}>
              <div className="space-y-3">
                <label className="block text-sm font-black text-gray-400 uppercase tracking-widest">আপনার নাম</label>
                <input name="name" required className="w-full border-2 border-rose-50 p-5 rounded-2xl focus:ring-4 focus:ring-rose-50 outline-none transition text-xl font-bold bg-rose-50/30" placeholder="আবরার আহমেদ" />
              </div>
              <div className="space-y-3">
                <label className="block text-sm font-black text-gray-400 uppercase tracking-widest">ফোন নম্বর</label>
                <input name="phone" required className="w-full border-2 border-rose-50 p-5 rounded-2xl focus:ring-4 focus:ring-rose-50 outline-none transition text-xl font-bold bg-rose-50/30" placeholder="017xxxxxxxx" />
              </div>
              <div className="space-y-3">
                <label className="block text-sm font-black text-gray-400 uppercase tracking-widest">পূর্ণ ঠিকানা</label>
                <textarea name="address" required rows={3} className="w-full border-2 border-rose-50 p-5 rounded-2xl focus:ring-4 focus:ring-rose-50 outline-none transition text-xl font-bold bg-rose-50/30" placeholder="বাসা নং, রোড নং, এলাকা, শহর..." />
              </div>
              <div className="bg-rose-500/10 p-6 rounded-3xl text-center font-black text-rose-700 text-xl shadow-inner border-4 border-rose-500">ক্যাশ অন ডেলিভারি (COD)</div>
              <button type="submit" className="w-full bg-rose-600 text-white py-6 rounded-2xl font-black hover:bg-rose-700 transition mt-8 text-2xl shadow-2xl shadow-rose-100 transform hover:-translate-y-1">অর্ডার নিশ্চিত করুন</button>
            </form>
          </div>
        )}

        {view === 'order-success' && (
          <div className="max-w-3xl mx-auto text-center py-32 bg-white rounded-[4rem] border border-rose-50 shadow-2xl px-12 font-hind">
            <div className="w-32 h-32 bg-rose-50 text-rose-500 rounded-full flex items-center justify-center mx-auto mb-10 shadow-inner ring-4 ring-rose-50 ring-offset-4"><CheckCircle size={72} /></div>
            <h1 className="text-4xl md:text-5xl font-black text-gray-900 mb-6">অভিনন্দন! আপনার অর্ডারটি পাওয়া গেছে।</h1>
            <p className="text-xl md:text-2xl text-rose-600 mb-12 leading-relaxed font-black">অল্প সময়ের মধ্যে আপনার সাথে যোগাযোগ করা হবে।</p>
            <button onClick={() => setView('home')} className="bg-rose-600 text-white px-16 py-5 rounded-full font-black hover:bg-rose-700 transition text-xl shadow-2xl shadow-rose-100">মেইন পেজে ফিরুন</button>
          </div>
        )}

        {view === 'admin' && (
          <div className="space-y-8">
            {!isAdminLoggedIn ? (
              <div className="max-w-md mx-auto py-16 font-hind">
                <div className="bg-white p-12 rounded-[3rem] border border-rose-50 shadow-2xl space-y-10">
                  <div className="text-center">
                    <div className="w-24 h-24 bg-rose-50 text-rose-600 rounded-[2rem] flex items-center justify-center mx-auto mb-8 shadow-inner rotate-3"><Lock size={48} /></div>
                    <h1 className="text-3xl font-black text-gray-900 leading-tight">এডমিন লগইন</h1>
                  </div>
                  {loginError && <div className="bg-rose-50 text-rose-600 p-4 rounded-2xl text-center font-black">{loginError}</div>}
                  <form className="space-y-6" onSubmit={handleAdminLogin}>
                    <input name="username" required className="w-full border-2 border-rose-50 bg-rose-50/30 p-5 rounded-2xl outline-none transition font-black text-lg" placeholder="Username" />
                    <input name="password" type="password" required className="w-full border-2 border-rose-50 bg-rose-50/30 p-5 rounded-2xl outline-none transition font-black text-lg" placeholder="••••••••" />
                    <div className="space-y-3 bg-rose-50/50 p-4 rounded-2xl border border-rose-100">
                        <div className="flex justify-between items-center px-2">
                            <span className="text-sm font-black text-gray-500 uppercase">সিকিউরিটি ক্যাপচা</span>
                            <span className="text-2xl font-black text-rose-600">{captcha.a} + {captcha.b} = ?</span>
                        </div>
                        <input type="number" required value={captchaInput} onChange={(e) => setCaptchaInput(e.target.value)} className="w-full border-2 border-rose-50 bg-white p-4 rounded-xl outline-none text-center font-black text-xl" placeholder="যোগফল লিখুন" />
                    </div>
                    <button type="submit" className="w-full bg-rose-950 text-white py-6 rounded-2xl font-black text-xl hover:bg-black transition shadow-2xl shadow-rose-100">প্রবেশ করুন</button>
                  </form>
                </div>
              </div>
            ) : (
              <div className="flex flex-col lg:flex-row gap-10 font-hind">
                <aside className="lg:w-72 shrink-0">
                  <div className="bg-white rounded-[2.5rem] border border-rose-50 shadow-sm p-6 sticky top-28">
                    <div className="flex items-center space-x-3 mb-8 px-4">
                      <div className="w-10 h-10 bg-rose-600 rounded-full flex items-center justify-center text-white font-black uppercase">{currentUser?.username[0]}</div>
                      <div className="font-black text-gray-900 leading-none">{currentUser?.username}</div>
                    </div>
                    <nav className="space-y-2">
                      <button onClick={() => { setAdminSubView('dashboard'); setSelectedOrder(null); }} className={`w-full flex items-center space-x-3 p-4 rounded-2xl font-black transition ${adminSubView === 'dashboard' ? 'bg-rose-600 text-white' : 'text-gray-500 hover:bg-rose-50'}`}><LayoutDashboard size={20} /> <span>ড্যাশবোর্ড</span></button>
                      <button onClick={() => { setAdminSubView('add-product'); setSelectedOrder(null); }} className={`w-full flex items-center space-x-3 p-4 rounded-2xl font-black transition ${adminSubView === 'add-product' ? 'bg-rose-600 text-white' : 'text-gray-500 hover:bg-rose-50'}`}><Plus size={20} /> <span>কালেকশন অ্যাড</span></button>
                      <button onClick={() => { setAdminSubView('new-orders'); setSelectedOrder(null); }} className={`w-full flex items-center space-x-3 p-4 rounded-2xl font-black transition ${adminSubView === 'new-orders' ? 'bg-rose-600 text-white' : 'text-gray-500 hover:bg-rose-50'}`}><Clock size={20} /> <span>নতুন অর্ডার</span></button>
                      <button onClick={() => { setAdminSubView('confirmed-orders'); setSelectedOrder(null); }} className={`w-full flex items-center space-x-3 p-4 rounded-2xl font-black transition ${adminSubView === 'confirmed-orders' ? 'bg-rose-600 text-white' : 'text-gray-500 hover:bg-rose-50'}`}><CheckCircle size={20} /> <span>কনফার্ম করা অর্ডার</span></button>
                      <div className="pt-8 mt-8 border-t border-rose-50"><button onClick={handleAdminLogout} className="w-full flex items-center space-x-3 p-4 rounded-2xl font-black text-rose-300 hover:text-rose-600 hover:bg-rose-50 transition"><LogOut size={20} /> <span>লগআউট</span></button></div>
                    </nav>
                  </div>
                </aside>
                <div className="flex-grow">
                  <header className="mb-10 bg-white p-8 rounded-[2rem] border border-rose-50 shadow-sm flex justify-between items-center">
                    <div><h1 className="text-3xl font-black text-gray-900 capitalize">{adminSubView.replace('-', ' ')}</h1><p className="text-rose-500 font-black uppercase tracking-widest text-xs mt-1">Unique Collection Admin</p></div>
                  </header>
                  {renderAdminContent()}
                </div>
              </div>
            )}
          </div>
        )}
      </main>

      <footer className="bg-rose-950 text-white py-24 mt-20 border-t-8 border-rose-900 font-hind">
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-20">
          <div className="space-y-10">
            <div className="flex items-center"><div className="w-14 h-14 bg-rose-600 rounded-full flex items-center justify-center text-white mr-4 shadow-2xl"><Heart size={28} fill="currentColor" /></div><span className="text-3xl font-black tracking-tighter">Unique Collection By Mehezabin</span></div>
            <p className="text-rose-200/80 leading-loose text-xl font-medium italic">"শাড়িতেই নারী, আর Unique Collection-এই সেরা শাড়ি।"</p>
          </div>
          <div className="space-y-10">
            <h4 className="text-2xl font-black border-b border-rose-800 pb-4 inline-block">সেবা সমূহ</h4>
            <ul className="space-y-5 text-rose-200 font-black text-lg"><li>প্রিমিয়াম কম্বো অফার</li><li>ঢাকাই জামদানি</li><li>কাতান কালেকশন</li></ul>
          </div>
          <div className="space-y-10">
            <h4 className="text-2xl font-black border-b border-rose-800 pb-4 inline-block">যোগাযোগ</h4>
            <ul className="space-y-5 text-rose-200 font-bold text-lg"><li className="flex items-center"><Search size={20} className="mr-3 text-rose-500" /> support@mehezabin.com</li><li className="flex items-center"><Plus size={20} className="mr-3 text-rose-500" /> +৮৮০ ১৭০০০০০০০০</li></ul>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
