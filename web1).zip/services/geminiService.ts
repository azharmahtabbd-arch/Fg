
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateProductDescription = async (productName: string, category: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Create a professional, persuasive, and detailed product description in Bengali for an e-commerce item named "${productName}" in the category "${category}". Highlight its benefits and features. Keep it within 150 words.`,
      config: {
        temperature: 0.7,
      },
    });
    return response.text || "দুঃখিত, বর্ণনাটি তৈরি করা সম্ভব হয়নি।";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "একটি ত্রুটি ঘটেছে। অনুগ্রহ করে আবার চেষ্টা করুন।";
  }
};
