
export interface Product {
  id: string;
  code: string; // Unique product code/SKU
  name: string;
  price: number;
  description: string;
  category: string;
  images: string[]; // Support for multiple images/colors
  colors?: string[]; // Support for multiple color names
}

export interface CartItem extends Product {
  quantity: number;
  selectedColor?: string;
}

export interface AdminUser {
  id: string;
  username: string;
  password: string;
  role: 'admin' | 'moderator';
}

export interface Order {
  id: string;
  items: CartItem[];
  total: number;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  customerAddress: string;
  status: 'pending' | 'confirmed' | 'cancelled' | 'shipped' | 'delivered';
  createdAt: string;
}

export type View = 'home' | 'product' | 'cart' | 'checkout' | 'admin' | 'order-success';
export type AdminSubView = 'dashboard' | 'add-product' | 'new-orders' | 'all-orders' | 'confirmed-orders' | 'manage-users';
